<?php

$eventHandler = new MAILBOX_CLASS_EventHandler();
$eventHandler->genericInit();
